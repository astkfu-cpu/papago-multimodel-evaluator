# Papago 在线绝对打分 0.28.1

打开 edge://extensions/ 或 chrome://extensions/，开启开发者模式，加载本文件夹。刷新获准访问的 Papago Pro 任务页，配置自己的模型 API Key，先核对单张再运行批量。插件免费，API 由使用者自行付费。更新请覆盖原目录并重新加载，不要卸载。完整说明：https://github.com/astkfu-cpu/papago-multimodel-evaluator
